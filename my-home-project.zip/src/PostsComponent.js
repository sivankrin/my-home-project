import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';  
function PostsComponent() {
    const [posts, setPosts] = useState([]);
    const [selectedAuthors, setSelectedAuthors] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);  
    const postsPerPage = 10;

    useEffect(() => {
        fetch('https://jsonplaceholder.typicode.com/posts')
            .then(response => response.json())
            .then(data => setPosts(data.map(post => ({
                ...post,
                lat: Math.random() * 180 - 90,  
                lng: Math.random() * 360 - 180  
            }))));
    }, []);

    const handleAuthorChange = (authorId) => {
        if (selectedAuthors.includes(authorId)) {
            setSelectedAuthors(selectedAuthors.filter(id => id !== authorId));
        } else {
            setSelectedAuthors([...selectedAuthors, authorId]);
        }
    };

    const filteredPosts = selectedAuthors.length > 0
        ? posts.filter(post => selectedAuthors.includes(post.userId))
        : posts;

    const sortedPosts = [...filteredPosts].sort((a, b) => a.title.localeCompare(b.title));

    const indexOfLastPost = currentPage * postsPerPage;
    const indexOfFirstPost = indexOfLastPost - postsPerPage;
    const currentPosts = sortedPosts.slice(indexOfFirstPost, indexOfLastPost);

    const totalPages = Math.ceil(filteredPosts.length / postsPerPage);
    const paginate = (pageNumber) => setCurrentPage(pageNumber);

    return (
        <div>
            <div>
                <label>
                    <input type="checkbox" value={1} onChange={() => handleAuthorChange(1)} />
                    User 1
                </label>
                <label>
                    <input type="checkbox" value={2} onChange={() => handleAuthorChange(2)} />
                    User 2
                </label>
                <label>
                    <input type="checkbox" value={3} onChange={() => handleAuthorChange(3)} />
                    User 3
                </label>
            </div>

            {currentPosts.map(post => (
                <div key={post.id}>
                    <h3>{post.title}</h3>
                    <p>{post.body}</p>
                    <MapContainer 
                        center={[post.lat, post.lng]} 
                        zoom={2} 
                        style={{ height: '200px', width: '100%' }}
                    >
                        <TileLayer
                            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        />
                        <Marker position={[post.lat, post.lng]}>
                            <Popup>{post.title}</Popup>
                        </Marker>
                    </MapContainer>
                </div>
            ))}

            <div>
                {Array.from({ length: totalPages }, (_, index) => (
                    <button key={index} onClick={() => paginate(index + 1)}>
                        {index + 1}
                    </button>
                ))}
            </div>
        </div>
    );
}

export default PostsComponent;
