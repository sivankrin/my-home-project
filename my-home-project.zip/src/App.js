import React from 'react';
import './App.css';
import PostsComponent from './PostsComponent';

function App() {
    return (
        <div className="App">
            <h1>Post Viewer</h1>
            <PostsComponent />
        </div>
    );
}

export default App;
